//
//  WriteToFile.swift
//  ExecutionTime
//
//  Created by Christopher Fonseka on 24/01/2017.
//  Copyright © 2017 ChristopherFonseka. All rights reserved.
//

import Foundation

extension String
{
    func writeToDesktopFile(called filename: String) throws
    {
        let file = getDesktopFile(called: filename)
        try self.write(to: file, atomically: false, encoding: .utf8)
    }
    
    mutating func removeLastCharacter()
    {
        self.remove(at: self.index(before: self.endIndex))
    }
    
    fileprivate func getDesktopFile (called name: String) -> URL
    {
        let paths = FileManager.default.urls(for: .desktopDirectory, in: .userDomainMask)
        let desktop = paths[0]
        return desktop.appendingPathComponent(name)
    }
}
