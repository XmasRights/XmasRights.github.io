//
//  main.swift
//  ExecutionTime
//
//  Created by Christopher Fonseka on 16/01/2017.
//  Copyright © 2017 ChristopherFonseka. All rights reserved.
//

import Foundation

struct TestCase
{
    let name : String
    let function : (Int) -> (Int)
}

func run(tests: [TestCase], toN n: Int) -> [String:[Double]]
{
    var result = [String: [Double]]()
    for test in tests
    {
        print("\(test.name)...")
        var times = [Double]()
        for i in 0...n
        {
            print("\(i)", separator: "", terminator: ",")
            let duration    = executionTime { _ = test.function(i) }
            let miliseconds = getMilliseconds(duration)
            times.append (miliseconds)
        }
        print("")
        result[test.name] = times
    }
    return result
}

func getCSVString (FromResult result : [String:[Double]]) -> String
{
    guard let count = result.first?.value.count else { return String() }
    
    var output = "n,"
    
    // Create Header
    let keys = result.keys
    for key in keys { output.append(key + ",") }
    
    output.removeLastCharacter()
    output.append("\n")
    
    // Create rows
    for i in 0..<count
    {
        var line = "\(i),"
        
        for key in keys
        {
            guard let entry = result[key] else { return String() }
            let entryString = String(format: "%f", entry[i])
            line.append("\(entryString),")
        }
        line.removeLastCharacter()
        line.append("\n")
        
        output.append(line)
    }
    return output
}


let tests  = [ TestCase(name: "Iterative",       function: Fibonacci.iterative),
               TestCase(name: "Memoized",        function: Fibonacci.memoized),
               TestCase(name: "Memoized Again",  function: Fibonacci.memoized)]

do
{
    print("-- Running Tests --")
    let result = run(tests: tests, toN: 90)
    
    print("-- Creating CSV String --")
    let output = getCSVString(FromResult: result)
    
    print("-- Writing to File --")
    try output.writeToDesktopFile(called: "Fibonacci.csv")
}
catch let error as NSError
{
    print("Error: \(error.localizedDescription)")
}
    
