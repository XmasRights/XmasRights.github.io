//
//  Fibonacci.swift
//  ExecutionTime
//
//  Created by Christopher Fonseka on 16/01/2017.
//  Copyright © 2017 ChristopherFonseka. All rights reserved.
//

import Foundation

struct Fibonacci
{
    @discardableResult static func recursive (n: Int) -> Int
    {
        precondition(n >= 0)
        
        if (n == 0 || n == 1) { return 1 }
        return recursive(n: n-1) + recursive(n: n-2)
    }

    @discardableResult static func iterative (n: Int) -> Int
    {
        precondition(n >= 0)

        if (n == 0 || n == 1) { return 1 }

        var a = 1, b = 1
        for _ in 1...(n - 1)
        {
            let c = b

            b = b + a
            a = c
        }
        return b
    }
    
    @discardableResult static func memoized (n: Int) -> Int
    {
        precondition(n >= 0)
        
        if (n == 0 || n == 1) { return 1 }
        
        if let result = memoizedResults[n]
        {
            return result
        }
        else
        {
            let result = memoized(n: n-1) + memoized(n: n-2)
            memoizedResults[n] = result
            return result
        }
    }
    
    private static var memoizedResults = [Int:Int]()
}
