//
//  ExecutionTime.swift
//  ExecutionTime
//
//  Created by Christopher Fonseka on 16/01/2017.
//  Copyright © 2017 ChristopherFonseka. All rights reserved.
//

import Foundation

func executionTime(function: ()->()) -> Measurement<UnitDuration>
{
    let start = DispatchTime.now()
    function()
    let end = DispatchTime.now()

    let nanoseconds = end.uptimeNanoseconds - start.uptimeNanoseconds
    let seconds     = Double(nanoseconds) / 1_000_000_000

    return Measurement(value: seconds, unit: UnitDuration.seconds)
}

internal func getMilliseconds (_ duration: Measurement<UnitDuration>) -> Double
{
    let seconds = duration.converted(to: .seconds)
    return seconds.value * 1_000
}
